#!/bin/sh
echo "Enable SSH (Dropbear SSH server)."
dbus-send --system --dest=com.mindscape.karotz.Led /com/mindscape/karotz/Led com.mindscape.karotz.KarotzInterface.pulse string:"" string:"660099" string:"000000" int32:400 int32:-1 >/dev/null 2>/dev/null

if grep -q "dropbear" "/usr/etc/inetd.conf"; then
    echo "Dropbear is already in inetd.conf!"
else
    echo "Patching file /usr/etc/inetd.conf, please wait..."
    echo -e "22 stream tcp nowait root /sbin/dropbear dropbear -i -B -R\n" >>/usr/etc/inetd.conf
    echo "Patching finished!"
fi

dbus-send --system --dest=com.mindscape.karotz.Led /com/mindscape/karotz/Led com.mindscape.karotz.KarotzInterface.pulse string:"" string:"00FF00" string:"000000" int32:700 int32:-1 >/dev/null 2>/dev/null
echo "Reboot your Karotz to start using SSH."
echo "Done!"
