#!/bin/sh
echo "Please wait while a new installpage is downloaded and installed..."
dbus-send --system --dest=com.mindscape.karotz.Led /com/mindscape/karotz/Led com.mindscape.karotz.KarotzInterface.pulse string:"" string:"660099" string:"000000" int32:400 int32:-1 >/dev/null 2>/dev/null
ZIPFILE="/tmp/installpage.zip"
URL="http://www.freerabbits.nl/downloads/karotz/installpage.zip"
if [ -f "${ZIPFILE}" ]; then
    echo "Removing previous download file."
    rm -f ${ZIPFILE}
fi
echo "Downloading file, please wait..."
if ! wget -O ${ZIPFILE} ${URL} ; then
    echo "Error downloading file! Refresh this page and try again! Done!"
    exit 1
fi
echo "Checking file..."
if [ -f "${ZIPFILE}" ]; then
    echo "MD5 checksum:"
    md5sum ${ZIPFILE}
    echo "Installing, please wait..."
    [ ! -d "/usr/www" ] && mkdir /usr/www
    /bin/unzip -oq ${ZIPFILE} -d /usr/www
    /bin/chmod 755 /usr/www/cgi-bin/*.sh
    echo "Install completed."
else
    echo "File does not exist: ${ZIPFILE}"
fi
dbus-send --system --dest=com.mindscape.karotz.Led /com/mindscape/karotz/Led com.mindscape.karotz.KarotzInterface.pulse string:"" string:"00FF00" string:"000000" int32:700 int32:-1 >/dev/null 2>/dev/null
echo "Done!"
