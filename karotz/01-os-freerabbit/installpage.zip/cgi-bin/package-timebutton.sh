#!/bin/sh
echo "Welcome to the installation of Timebutton (as package of Free Rabbits OS)."
echo "Please wait while Timebutton is installed..."
dbus-send --system --dest=com.mindscape.karotz.Led /com/mindscape/karotz/Led com.mindscape.karotz.KarotzInterface.pulse string:"" string:"660099" string:"000000" int32:400 int32:-1 >/dev/null 2>/dev/null

NewVersion="01e"
CurrentVersion="Unknown"
if [ -f "/usr/karotz/timebuttonversion.conf" ]; then
    CurrentVersion=$(cat /usr/karotz/timebuttonversion.conf)
fi
echo "Current version: ${CurrentVersion}" 
echo "New version: ${NewVersion}" 

# start download the files we need
echo "Downloading files, please wait..."
echo "Downloading package Timebutton as ZIP file, please wait..."
if ! wget -O /tmp/package-timebutton.zip http://www.freerabbits.nl/downloads/karotz/package-timebutton.zip ; then
    echo "Error downloading file! Refresh this page and try again! Done!"
    exit 1
fi
echo "End downloading files, installation will start..."
# end download the files we need

# Start extract package file
echo "Extracting the packagefile, please wait..."
unzip -q -o /tmp/package-timebutton.zip -d /tmp
# End extract package file

if [ -f  "/sys/class/net/wlan0/address" ]; then
    mac=$(sed 's/:/-/g' /sys/class/net/wlan0/address)
    echo "Setting MAC address to ${mac}..."
    sed -i "s/00-00-00-00-00-00/${mac}/g" /tmp/FreeRabbits/commander.py
fi

if [ -f  "/usr/karotz/uuid.conf" ]; then
    uuid=$(cat /usr/karotz/uuid.conf)
    echo "Setting UUID to ${uuid}..."
    sed -i "s/00000000-0000-0000-0000-000000000000/${uuid}/g" /tmp/FreeRabbits/commander.py
fi

echo "Copying button watcher..."
cp -f /tmp/FreeRabbits/dbus_events /usr/scripts/dbus_watcher
/bin/chmod 755 /usr/scripts/dbus_watcher

echo "Copying Timebutton files..."
cp -r /tmp/FreeRabbits /usr/karotz

echo "Changing permissions..."
/bin/chmod 755 /usr/karotz/FreeRabbits/*

echo "Writing new version..."
echo "${NewVersion}" >/usr/karotz/timebuttonversion.conf

dbus-send --system --dest=com.mindscape.karotz.Led /com/mindscape/karotz/Led com.mindscape.karotz.KarotzInterface.pulse string:"" string:"00FF00" string:"000000" int32:700 int32:-1 >/dev/null 2>/dev/null
echo "End installing TimeButton (as package of Free Rabbits OS)."
echo "Your Karotz will reboot after 5 seconds."
echo "When startup is finished, press the button and visit http://www.freerabbits.nl/timebutton to start using TimeButton."
echo "Done!"
sleep 5
/sbin/reboot
